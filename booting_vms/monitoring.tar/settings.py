SERVER='http://150.162.63.25'
SERVER_PORT='60001'                    
